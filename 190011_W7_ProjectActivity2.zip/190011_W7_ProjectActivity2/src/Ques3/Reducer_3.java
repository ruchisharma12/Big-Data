package Ques3;
/**************
 * @Title: Finding the top ten hot and the cold days: Reducer class
 * 
 * @Description:This reducer class receives data after analyzation and returns only the required information
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This reducer class  sends the analyzed data
 */

	import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

	    
	public class Reducer_3 extends Reducer<Text, Text, Text, Text>
	{
	
	public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
	{
		
	  con.write(word, values);
	   
	}
	
	

	}

