package Ques3;
/**************
 * @Title: Top hottest and the coldest days: Mapper class
 * 
 * @Description:  This mapper class reads the big data line by line and extracts the required data and sends it to reducer for analysis
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This mapper class extract and sends the date, top 10 maximum and minimum temperature to reducer
 */
	import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

	public class Mapper_3 extends Mapper<LongWritable, Text, Text, Text>{
		private TreeMap<Text, Text> hMap, cMap;// two different treemap for extracting top 10 hot and cold days
		@Override
		public void setup(Context context ) throws IOException, InterruptedException{
			hMap = new TreeMap<Text, Text>();// to store the data of hot days 
			cMap = new TreeMap<Text, Text>();//to store the data of cold days
		}
		public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
		{
		String line = value.toString();
		//ignoring the empty lines
		if(!(line.length()==0)){
			//getting the date
		String date = line.substring(6,14).trim();
		//getting the minimum temperature of each day
		float temp_min = Float.parseFloat(line.substring(47,53).trim());
		//getting the maximum temperature of each day
		float temp_max = Float.parseFloat(line.substring(39,45).trim());
		
		if(temp_max>35){
		hMap.put(new Text(date+" had the top maximum temparture of: "), new Text(String.valueOf(temp_max)));
		//removing the extra data except the top ten
		if(hMap.size()>10){
			hMap.remove(hMap.firstKey());
		}}
		if(temp_min<10){
			cMap.put(new Text(date+" had the top minimum temparture of: "), new Text(String.valueOf(temp_min)));
			//removing the extra data except the top ten
			if(cMap.size()>10){
				cMap.remove(cMap.lastKey());
			}}
		}
		}
		
		@Override
		public void cleanup(Context context ) throws IOException, InterruptedException{
			
			//sending the values to the reducer
				for(Map.Entry <Text, Text>entry : hMap.entrySet()){
			    Text value  = entry.getValue();
				Text word = entry.getKey();
				context.write(word, value);
			}
				//sending the values to the reducer
				for(Map.Entry <Text, Text>entry : cMap.entrySet()){
				    Text value  = entry.getValue();
					Text word = entry.getKey();
					context.write(word, value);
				}
			
			
			
		}
	}
		



