package Ques2;
/**************
 * @Title: Finding the hot and the cold days: Mapper class
 * 
 * @Description:  This mapper class reads the big data line by line and extracts the required data: date and average temperature and sends it to reducer for analysis
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This mapper class extract and sends the date and average temperature to reducer with appropriate message
 */
	import java.io.IOException;
	import org.apache.hadoop.io.IntWritable;
	import org.apache.hadoop.io.LongWritable;
	import org.apache.hadoop.io.Text;
	import org.apache.hadoop.mapreduce.Mapper;

	public class Mapper_2 extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
	{
	String line = value.toString();
	//checking for empty line
	if(!(line.length()==0)){
	String date = line.substring(6,14).trim();
	//Getting the average temperature to analyze
	String temp = line.substring(63,69).trim();
	Float temperature = Float.parseFloat(temp);
	//if the temperature is more than 35 its a hot day
	if(temperature> 35){
		con.write(new Text("It was a Hot day: "+ date+" with temperature :"), new Text(temp));
	}
	//if the temperature is less than 10 it is a cold day
	if(temperature<10){
		con.write(new Text("It is a Cold day: "+ date+" with temperature :"), new Text(temp));
	}
	}
	}
	}



