package Ques2;
/**************
 * @Title: Finding the hot and the cold days: Reducer class
 * 
 * @Description:This reducer class receives data after analyzation and returns only the required information
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This reducer class  sends the analyzed data
 */

	import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

	    
	public class Reducer2 extends Reducer<Text, Text, Text, Text>
	{
	public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
	{
		//writing the analyzed data coming from mapper
		
	   con.write(word, values);
	}
	}

	

