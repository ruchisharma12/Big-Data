package Ques1;
/**************
 * @Title: Highest temperature of each year: Job class
 * 
 * @Description: This  job class configures the job, submits and controls its execution and gets the required query
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This job class drives the map and reduce to extract the highest temperature for each year
 */
	import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

	public class Job_1 {
		     
		public static void main(String [] args) throws Exception
		{
			//Reads the default configuration of the cluster from the configured xml file
		Configuration c=new Configuration();
		String[] files=new GenericOptionsParser(c,args).getRemainingArgs();
		Path input=new Path(files[0]);
		Path output=new Path(files[1]);
		//Initializing the job with default confi of the cluster
		Job j=new Job(c,"Temperaturecount");
		//Assigning the driver class name
		j.setJarByClass(Job_1.class);
		//defining the key typr
		j.setOutputKeyClass(Text.class);
		//defining the value type
		j.setOutputValueClass(Text.class);
		//defining the mapper class
		j.setMapperClass(Mapper_1.class);
		//defining the reducer class
		j.setReducerClass(Reducer1.class);
		//defining the input format class
		j.setInputFormatClass(TextInputFormat.class);
		//defining the output format class
		j.setOutputFormatClass(TextOutputFormat.class);
		//Configuring the input file path from the file system into the job
		FileInputFormat.addInputPath(j, input);
		//Configuring the output file path from the file system into the job
		FileOutputFormat.setOutputPath(j, output);
		//deleting the context path manually so that we dont have to delete it explicitly
		output.getFileSystem(c).delete(output);
		//exiting thr job when the flag value is false
		System.exit(j.waitForCompletion(true)?0:1);
		} 

	}


