package Ques1;
/**************
 * @Title: Highest temperature of each year: Mapper class
 * 
 * @Description: This mapper class reads the big data line by line and extracts the required data and sends it to reducer for analysis
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This mapper extract and sends the date and average temperature to reducer
 */
	import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

	public class Mapper_1 extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
	{
	String line = value.toString();
	//Not sending any empty line for 
	if(!(line.length()==0)){
		//getting the date 
	String date =line.substring(6,10).trim();
	  Text outputKey = new Text(date);
	  // getting the average temperature
		String temp =line.substring(63,69).trim();
	  Text outputValue = new Text(temp);
	  float ftemp = Float.parseFloat(temp);
	  //checking for high temperatures to write into configuration
	  if(ftemp>35)
	  con.write(new Text("Highest temperature of "+outputKey+"is :"), outputValue);
	}
	}
	}



