package Ques1;
/**************
 * @Title: Highest temperature of each year: Reducer class
 * 
 * @Description: This reducer class receives data for analyzation and returns only the required information
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This reducer sends only the highest temperature for each year
 * 
 *  */

	import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

	    
	public class Reducer1 extends Reducer<Text, Text, Text, Text>
	{
	public void reduce(Text word, Iterable<Text> values, Context con) throws IOException, InterruptedException
	{
		
	float maximum = 0;
	//traversing each value
	   for(Text value : values)
	   {
		   float temp = Float.parseFloat(value.toString());
		   //checking for the maximum value of each year
		   if(temp>maximum){
			   maximum=temp;
		   }
	   
	   }
	   //writing only the maximum temperature of each year
	   con.write(word, new Text(String.valueOf(maximum)));
	}
	}
	

