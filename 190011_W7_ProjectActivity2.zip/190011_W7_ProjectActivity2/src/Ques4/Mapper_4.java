package Ques4;
/**************
 * @Title: Maximum and minimum temperature of each day: Mapper class
 * 
 * @Description:  This mapper class reads the big data line by line and extracts the required data and sends it to reducer for analysis
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This mapper class extract and sends the date, maximum and minimum temperature to reducer
 */
	import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;

	public class Mapper_4 extends Mapper<LongWritable, Text, Text, Text>{
	public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
	{
	String line = value.toString();
	//checking for empty lines
	if(!(line.length()==0)){
		//getting the dates
	String date = line.substring(6,14).trim();
	//getting the minimum temperature of each day
	String temp_min = line.substring(47,53).trim();
	//getting the maximum temperature of each day
	String temp_max = line.substring(39,45).trim();
	
	
		//sending the minimum temperature for the day
		con.write(new Text("Minimum temparture on: "+ date+ " was :"), new Text(temp_min));
	
		//sending the maximum temperature for the day
		con.write(new Text("Maximum temparture on : "+ date+" was :"), new Text(temp_max));
	
	}
	}}


