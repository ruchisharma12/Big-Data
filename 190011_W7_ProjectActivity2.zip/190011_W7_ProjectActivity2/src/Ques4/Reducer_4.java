package Ques4;

/**************
 * @Title: Maximum and minimum temperature of each day: Reducer class
 * 
 * @Description:This reducer class receives data after analyzation and returns only the required information
 * 
 * @Copyright: Ruchi Sharma@2021
 * 
 * @Author:Ruchi Sharma
 * 
 * @Version: 1.00 This reducer class  sends the analyzed data
 */
	import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

	    
public class Reducer_4 extends Reducer<Text, Text, Text, Text>
{
	public void reduce(Text word, Text values, Context con) throws IOException, InterruptedException
	{
		
	   con.write(word, values);
	}
}

